import { useState, useEffect, useMemo } from "react";
import {
  Smartphone, Wrench, Package, ShoppingCart, History, LayoutDashboard,
  Plus, Trash2, Pencil, Search, AlertTriangle, X, Check, Minus,
  ClipboardList, Eye, EyeOff, ArrowRightCircle, Users, Bell, StickyNote, ArrowLeft
} from "lucide-react";

const SUPABASE_URL = "https://vmhwriebfuuabnzbjhdn.supabase.co";
const SUPABASE_ANON_KEY =
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InZtaHdyaWViZnV1YWJuemJqaGRuIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODQzNDMxMDEsImV4cCI6MjA5OTkxOTEwMX0.AcLKesWWKpUpy-vxcNDDJjw-yT25QtalR5Sfa2nQNeI";

let syncListener = null;
let activeRequests = 0;
function notifySync(state) { if (syncListener) syncListener(state); }

async function sb(path, options = {}) {
  activeRequests++;
  notifySync("saving");
  try {
    const res = await fetch(`${SUPABASE_URL}/rest/v1/${path}`, {
      ...options,
      headers: {
        apikey: SUPABASE_ANON_KEY,
        Authorization: `Bearer ${SUPABASE_ANON_KEY}`,
        "Content-Type": "application/json",
        Prefer: options.prefer || "return=representation",
        ...(options.headers || {}),
      },
    });
    if (!res.ok) {
      const text = await res.text().catch(() => "");
      throw new Error(`Supabase ${res.status}: ${text}`);
    }
    activeRequests = Math.max(0, activeRequests - 1);
    if (activeRequests === 0) {
      notifySync("saved");
      setTimeout(() => { if (activeRequests === 0) notifySync("idle"); }, 1200);
    }
    if (res.status === 204) return null;
    const text = await res.text();
    return text ? JSON.parse(text) : null;
  } catch (e) {
    activeRequests = Math.max(0, activeRequests - 1);
    notifySync("error");
    setTimeout(() => { if (activeRequests === 0) notifySync("idle"); }, 3000);
    throw e;
  }
}

// Mapea entre los nombres camelCase que usa la app y snake_case de las tablas
const itemFromRow = (r) => ({
  id: r.id, name: r.name, brand: r.brand || "", category: r.category,
  quantity: r.quantity, cost: r.cost, price: r.price, minStock: r.min_stock,
});
const itemToRow = (i) => ({
  name: i.name, brand: i.brand || "", category: i.category,
  quantity: Number(i.quantity) || 0, cost: Number(i.cost) || 0,
  price: Number(i.price) || 0, min_stock: Number(i.minStock) || 0,
});

const saleFromRow = (r) => ({
  id: r.id, date: r.created_at, customer: r.customer || "",
  device: r.device || "", items: r.items || [], total: r.total,
  warrantyDays: r.warranty_days || 0,
});
const saleToRow = (s) => ({
  customer: s.customer || "", device: s.device || "", items: s.items,
  total: s.total, warranty_days: Number(s.warrantyDays) || 0,
});

const orderFromRow = (r) => ({
  id: r.id, folio: r.folio, customerName: r.customer_name || "",
  customerPhone: r.customer_phone || "", deviceBrand: r.device_brand || "",
  deviceModel: r.device_model || "", deviceColor: r.device_color || "",
  password: r.password || "", checklist: r.checklist || [],
  otherIssue: r.other_issue || "", accessories: r.accessories || "",
  estimatedCost: r.estimated_cost, status: r.status, dateReceived: r.date_received,
});
const orderToRow = (o) => ({
  customer_name: o.customerName || "", customer_phone: o.customerPhone || "",
  device_brand: o.deviceBrand || "", device_model: o.deviceModel || "",
  device_color: o.deviceColor || "", password: o.password || "",
  checklist: o.checklist || [], other_issue: o.otherIssue || "",
  accessories: o.accessories || "",
  estimated_cost: o.estimatedCost === "" || o.estimatedCost == null ? null : Number(o.estimatedCost),
  status: o.status,
});

const customerFromRow = (r) => ({
  id: r.id, name: r.name, phone: r.phone || "", email: r.email || "",
  notes: r.notes || [], createdAt: r.created_at,
});
const customerToRow = (c) => ({ name: c.name, phone: c.phone || "", email: c.email || "", notes: c.notes || [] });

const reminderFromRow = (r) => ({
  id: r.id, customerId: r.customer_id, message: r.message,
  dueDate: r.due_date, done: r.done, createdAt: r.created_at,
});
const reminderToRow = (r) => ({
  customer_id: r.customerId, message: r.message, due_date: r.dueDate || null, done: r.done,
});

const CATEGORIES = [
  "Pantallas", "Baterías", "Puertos de carga", "Cámaras",
  "Placas / IC", "Herramientas", "Accesorios", "Otro",
];

const BUSINESS_NAME = "Celvis Reparaciones";
const BUSINESS_TAGLINE = "Reparación de celulares";

const money = (n) => `$${Number(n || 0).toFixed(2)}`;
const todayStr = () => new Date().toISOString().slice(0, 10);
const monthStr = () => new Date().toISOString().slice(0, 7);

function downloadCSV(filename, rows) {
  if (!rows.length) return;
  const headers = Object.keys(rows[0]);
  const escape = (v) => {
    const s = v == null ? "" : String(v);
    return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  const csv = [headers.join(","), ...rows.map((r) => headers.map((h) => escape(r[h])).join(","))].join("\n");
  const blob = new Blob(["\ufeff" + csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = filename;
  document.body.appendChild(a); a.click(); document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

const emptyItem = {
  name: "", brand: "", category: CATEGORIES[0],
  quantity: 0, cost: 0, price: 0, minStock: 3,
};

const CHECKLIST_ITEMS = [
  { key: "enciende", label: "Enciende" },
  { key: "noCarga", label: "No carga" },
  { key: "seApaga", label: "Se apaga solo" },
  { key: "seMojo", label: "Se mojó" },
  { key: "pantallaRota", label: "Pantalla rota / dañada" },
  { key: "noSim", label: "No reconoce SIM" },
  { key: "sinSonido", label: "Sin sonido / micrófono" },
  { key: "botones", label: "Botones no funcionan" },
  { key: "camara", label: "Cámara dañada" },
];

const STATUS_OPTIONS = ["Recibido", "En diagnóstico", "En reparación", "Listo para entrega", "Entregado"];
const STATUS_STYLES = {
  "Recibido": "bg-zinc-800 text-zinc-300 border-zinc-700",
  "En diagnóstico": "bg-amber-950/40 text-amber-400 border-amber-800/60",
  "En reparación": "bg-teal-950/40 text-teal-400 border-teal-800/60",
  "Listo para entrega": "bg-emerald-950/40 text-emerald-400 border-emerald-800/60",
  "Entregado": "bg-zinc-900 text-zinc-500 border-zinc-800",
};

const emptyOrder = {
  customerName: "", customerPhone: "", deviceBrand: "", deviceModel: "",
  deviceColor: "", password: "", checklist: [], otherIssue: "",
  accessories: "", estimatedCost: "", status: STATUS_OPTIONS[0],
};

const emptyCustomer = { name: "", phone: "", email: "" };

export default function TallerApp() {
  const [tab, setTab] = useState("dashboard");
  const [loading, setLoading] = useState(true);
  const [inventory, setInventory] = useState([]);
  const [sales, setSales] = useState([]);
  const [orders, setOrders] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [reminders, setReminders] = useState([]);

  const [customerModalOpen, setCustomerModalOpen] = useState(false);
  const [editingCustomerId, setEditingCustomerId] = useState(null);
  const [customerForm, setCustomerForm] = useState(emptyCustomer);
  const [customerSearch, setCustomerSearch] = useState("");
  const [activeCustomerId, setActiveCustomerId] = useState(null);
  const [noteDraft, setNoteDraft] = useState("");
  const [reminderMsg, setReminderMsg] = useState("");
  const [reminderDue, setReminderDue] = useState("");

  const [modalOpen, setModalOpen] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [form, setForm] = useState(emptyItem);
  const [invSearch, setInvSearch] = useState("");

  const [orderModalOpen, setOrderModalOpen] = useState(false);
  const [editingOrderId, setEditingOrderId] = useState(null);
  const [orderForm, setOrderForm] = useState(emptyOrder);
  const [orderSearch, setOrderSearch] = useState("");
  const [showPassword, setShowPassword] = useState(false);

  const [cart, setCart] = useState([]);
  const [posSearch, setPosSearch] = useState("");
  const [customer, setCustomer] = useState("");
  const [device, setDevice] = useState("");
  const [warrantyDays, setWarrantyDays] = useState(0);
  const [confirmMsg, setConfirmMsg] = useState("");
  const [loadError, setLoadError] = useState("");

  const [globalSearch, setGlobalSearch] = useState("");
  const [globalSearchOpen, setGlobalSearchOpen] = useState(false);
  const [receiptSale, setReceiptSale] = useState(null);
  const [receiptOrder, setReceiptOrder] = useState(null);
  const [undoToast, setUndoToast] = useState(null);
  const [syncState, setSyncState] = useState("idle");

  useEffect(() => {
    syncListener = (s) => setSyncState(s);
    return () => { syncListener = null; };
  }, []);

  const triggerUndo = (message, restoreFn) => setUndoToast({ message, restoreFn });
  useEffect(() => {
    if (!undoToast) return;
    const t = setTimeout(() => setUndoToast(null), 6000);
    return () => clearTimeout(t);
  }, [undoToast]);

  useEffect(() => {
    (async () => {
      try {
        const [inv, sl, ord, cust, rem] = await Promise.all([
          sb("inventory?select=*&order=created_at.asc"),
          sb("sales?select=*&order=created_at.asc"),
          sb("orders?select=*&order=date_received.asc"),
          sb("customers?select=*&order=created_at.asc"),
          sb("reminders?select=*&order=due_date.asc"),
        ]);
        setInventory((inv || []).map(itemFromRow));
        setSales((sl || []).map(saleFromRow));
        setOrders((ord || []).map(orderFromRow));
        setCustomers((cust || []).map(customerFromRow));
        setReminders((rem || []).map(reminderFromRow));
      } catch (e) {
        console.error(e);
        setLoadError(`No se pudo conectar con la base de datos. Detalle: ${e.message}`);
      }
      setLoading(false);
    })();
  }, []);

  const openNewOrder = () => { setEditingOrderId(null); setOrderForm(emptyOrder); setShowPassword(false); setOrderModalOpen(true); };
  const openEditOrder = (order) => { setEditingOrderId(order.id); setOrderForm(order); setShowPassword(false); setOrderModalOpen(true); };

  const toggleChecklistItem = (key) => {
    setOrderForm((f) => ({
      ...f,
      checklist: f.checklist.includes(key) ? f.checklist.filter((k) => k !== key) : [...f.checklist, key],
    }));
  };

  const saveOrder = async () => {
    if (!orderForm.customerName.trim() && !orderForm.deviceModel.trim()) return;
    const payload = orderToRow(orderForm);
    try {
      if (editingOrderId) {
        const [row] = await sb(`orders?id=eq.${editingOrderId}`, { method: "PATCH", body: JSON.stringify(payload) });
        setOrders((prev) => prev.map((o) => (o.id === editingOrderId ? orderFromRow(row) : o)));
      } else {
        const [row] = await sb("orders", { method: "POST", body: JSON.stringify(payload) });
        setOrders((prev) => [...prev, orderFromRow(row)]);
      }
      setOrderModalOpen(false);
    } catch (e) {
      console.error(e);
      alert("No se pudo guardar la recepción. Intenta de nuevo.");
    }
  };

  const deleteOrder = async (id) => {
    const order = orders.find((o) => o.id === id);
    try {
      await sb(`orders?id=eq.${id}`, { method: "DELETE" });
      setOrders((prev) => prev.filter((o) => o.id !== id));
      if (order) {
        triggerUndo(`Recepción de "${order.deviceModel || order.customerName}" eliminada`, async () => {
          const [row] = await sb("orders", { method: "POST", body: JSON.stringify(orderToRow(order)) });
          setOrders((prev) => [...prev, orderFromRow(row)]);
        });
      }
    } catch (e) {
      console.error(e);
      alert("No se pudo eliminar la orden.");
    }
  };

  const updateOrderStatus = async (id, status) => {
    try {
      const [row] = await sb(`orders?id=eq.${id}`, { method: "PATCH", body: JSON.stringify({ status }) });
      setOrders((prev) => prev.map((o) => (o.id === id ? orderFromRow(row) : o)));
    } catch (e) {
      console.error(e);
      alert("No se pudo actualizar el estado.");
    }
  };

  const sendOrderToSales = (order) => {
    setCustomer(order.customerName);
    setDevice(`${order.deviceBrand} ${order.deviceModel}`.trim());
    setTab("sales");
  };

  const filteredOrders = useMemo(() => {
    const q = orderSearch.trim().toLowerCase();
    const sorted = [...orders].sort((a, b) => new Date(b.dateReceived) - new Date(a.dateReceived));
    if (!q) return sorted;
    return sorted.filter((o) =>
      o.customerName.toLowerCase().includes(q) ||
      o.deviceModel.toLowerCase().includes(q) ||
      o.deviceBrand.toLowerCase().includes(q)
    );
  }, [orders, orderSearch]);

  const openNewItem = () => { setEditingId(null); setForm(emptyItem); setModalOpen(true); };
  const openEditItem = (item) => { setEditingId(item.id); setForm(item); setModalOpen(true); };

  const openNewCustomer = () => { setEditingCustomerId(null); setCustomerForm(emptyCustomer); setCustomerModalOpen(true); };
  const openEditCustomer = (c) => { setEditingCustomerId(c.id); setCustomerForm(c); setCustomerModalOpen(true); };

  const saveCustomer = async () => {
    if (!customerForm.name.trim()) return;
    const payload = customerToRow(customerForm);
    try {
      if (editingCustomerId) {
        const [row] = await sb(`customers?id=eq.${editingCustomerId}`, { method: "PATCH", body: JSON.stringify(payload) });
        setCustomers((prev) => prev.map((c) => (c.id === editingCustomerId ? customerFromRow(row) : c)));
      } else {
        const [row] = await sb("customers", { method: "POST", body: JSON.stringify(payload) });
        setCustomers((prev) => [...prev, customerFromRow(row)]);
      }
      setCustomerModalOpen(false);
    } catch (e) {
      console.error(e);
      alert("No se pudo guardar el cliente. Intenta de nuevo.");
    }
  };

  const deleteCustomer = async (id) => {
    const cust = customers.find((c) => c.id === id);
    try {
      await sb(`customers?id=eq.${id}`, { method: "DELETE" });
      setCustomers((prev) => prev.filter((c) => c.id !== id));
      setReminders((prev) => prev.filter((r) => r.customerId !== id));
      if (activeCustomerId === id) setActiveCustomerId(null);
      if (cust) {
        triggerUndo(`Cliente "${cust.name}" eliminado`, async () => {
          const [row] = await sb("customers", { method: "POST", body: JSON.stringify(customerToRow(cust)) });
          setCustomers((prev) => [...prev, customerFromRow(row)]);
        });
      }
    } catch (e) {
      console.error(e);
      alert("No se pudo eliminar el cliente.");
    }
  };

  const addNote = async (customerId) => {
    const text = noteDraft.trim();
    if (!text) return;
    const cust = customers.find((c) => c.id === customerId);
    if (!cust) return;
    const nextNotes = [...cust.notes, { date: new Date().toISOString(), text }];
    try {
      const [row] = await sb(`customers?id=eq.${customerId}`, { method: "PATCH", body: JSON.stringify({ notes: nextNotes }) });
      setCustomers((prev) => prev.map((c) => (c.id === customerId ? customerFromRow(row) : c)));
      setNoteDraft("");
    } catch (e) {
      console.error(e);
      alert("No se pudo guardar la nota.");
    }
  };

  const addReminder = async (customerId) => {
    if (!reminderMsg.trim() || !reminderDue) return;
    const payload = reminderToRow({ customerId, message: reminderMsg.trim(), dueDate: reminderDue, done: false });
    try {
      const [row] = await sb("reminders", { method: "POST", body: JSON.stringify(payload) });
      setReminders((prev) => [...prev, reminderFromRow(row)]);
      setReminderMsg(""); setReminderDue("");
    } catch (e) {
      console.error(e);
      alert("No se pudo crear el recordatorio.");
    }
  };

  const toggleReminderDone = async (id, done) => {
    try {
      const [row] = await sb(`reminders?id=eq.${id}`, { method: "PATCH", body: JSON.stringify({ done }) });
      setReminders((prev) => prev.map((r) => (r.id === id ? reminderFromRow(row) : r)));
    } catch (e) {
      console.error(e);
      alert("No se pudo actualizar el recordatorio.");
    }
  };

  const deleteReminder = async (id) => {
    const rem = reminders.find((r) => r.id === id);
    try {
      await sb(`reminders?id=eq.${id}`, { method: "DELETE" });
      setReminders((prev) => prev.filter((r) => r.id !== id));
      if (rem) {
        triggerUndo(`Recordatorio "${rem.message}" eliminado`, async () => {
          const [row] = await sb("reminders", { method: "POST", body: JSON.stringify(reminderToRow(rem)) });
          setReminders((prev) => [...prev, reminderFromRow(row)]);
        });
      }
    } catch (e) {
      console.error(e);
      alert("No se pudo eliminar el recordatorio.");
    }
  };

  const norm = (s) => (s || "").trim().toLowerCase();
  const customerStats = (customer) => {
    const matchSales = sales.filter((s) => norm(s.customer) === norm(customer.name) && norm(customer.name));
    const matchOrders = orders.filter((o) => norm(o.customerName) === norm(customer.name) && norm(customer.name));
    const totalSpent = matchSales.reduce((s, x) => s + x.total, 0);
    const dates = [...matchSales.map((s) => s.date), ...matchOrders.map((o) => o.dateReceived)];
    const lastVisit = dates.length ? new Date(Math.max(...dates.map((d) => new Date(d)))) : null;
    return { matchSales, matchOrders, totalSpent, visits: matchOrders.length, lastVisit };
  };

  const filteredCustomers = useMemo(() => {
    const q = customerSearch.trim().toLowerCase();
    if (!q) return customers;
    return customers.filter((c) => c.name.toLowerCase().includes(q) || (c.phone || "").includes(q));
  }, [customers, customerSearch]);

  const pendingReminders = reminders
    .filter((r) => !r.done && r.dueDate && r.dueDate <= todayStr())
    .sort((a, b) => new Date(a.dueDate) - new Date(b.dueDate));

  const findActiveWarranty = (custName, devModel) => {
    const nc = norm(custName), nd = norm(devModel);
    if (!nc || !nd) return null;
    return sales.find((s) => {
      if (!s.warrantyDays) return false;
      if (norm(s.customer) !== nc) return false;
      if (!norm(s.device).includes(nd)) return false;
      const until = new Date(s.date);
      until.setDate(until.getDate() + s.warrantyDays);
      return new Date() <= until;
    }) || null;
  };

  const globalResults = useMemo(() => {
    const q = globalSearch.trim().toLowerCase();
    if (!q) return { items: [], orders: [], customers: [] };
    return {
      items: inventory.filter((i) => i.name.toLowerCase().includes(q) || (i.brand || "").toLowerCase().includes(q)).slice(0, 5),
      orders: orders.filter((o) => o.customerName.toLowerCase().includes(q) || o.deviceModel.toLowerCase().includes(q)).slice(0, 5),
      customers: customers.filter((c) => c.name.toLowerCase().includes(q) || (c.phone || "").includes(q)).slice(0, 5),
    };
  }, [globalSearch, inventory, orders, customers]);

  const saveItem = async () => {
    if (!form.name.trim()) return;
    const payload = itemToRow(form);
    try {
      if (editingId) {
        const [row] = await sb(`inventory?id=eq.${editingId}`, { method: "PATCH", body: JSON.stringify(payload) });
        setInventory((prev) => prev.map((i) => (i.id === editingId ? itemFromRow(row) : i)));
      } else {
        const [row] = await sb("inventory", { method: "POST", body: JSON.stringify(payload) });
        setInventory((prev) => [...prev, itemFromRow(row)]);
      }
      setModalOpen(false);
    } catch (e) {
      console.error(e);
      alert("No se pudo guardar el repuesto. Intenta de nuevo.");
    }
  };

  const deleteItem = async (id) => {
    const item = inventory.find((i) => i.id === id);
    try {
      await sb(`inventory?id=eq.${id}`, { method: "DELETE" });
      setInventory((prev) => prev.filter((i) => i.id !== id));
      setCart((c) => c.filter((c2) => c2.itemId !== id));
      if (item) {
        triggerUndo(`Repuesto "${item.name}" eliminado`, async () => {
          const [row] = await sb("inventory", { method: "POST", body: JSON.stringify(itemToRow(item)) });
          setInventory((prev) => [...prev, itemFromRow(row)]);
        });
      }
    } catch (e) {
      console.error(e);
      alert("No se pudo eliminar el repuesto.");
    }
  };

  const filteredInventory = useMemo(() => {
    const q = invSearch.trim().toLowerCase();
    if (!q) return inventory;
    return inventory.filter((i) =>
      i.name.toLowerCase().includes(q) ||
      (i.brand || "").toLowerCase().includes(q) ||
      i.category.toLowerCase().includes(q)
    );
  }, [inventory, invSearch]);

  const posResults = useMemo(() => {
    const q = posSearch.trim().toLowerCase();
    const base = q
      ? inventory.filter((i) => i.name.toLowerCase().includes(q) || (i.brand || "").toLowerCase().includes(q))
      : inventory;
    return base.filter((i) => i.quantity > 0);
  }, [inventory, posSearch]);

  const addToCart = (item) => {
    setCart((c) => {
      const existing = c.find((x) => x.itemId === item.id);
      if (existing) {
        if (existing.qty >= item.quantity) return c;
        return c.map((x) => (x.itemId === item.id ? { ...x, qty: x.qty + 1 } : x));
      }
      return [...c, { itemId: item.id, name: item.name, price: item.price, qty: 1, maxQty: item.quantity }];
    });
  };
  const changeCartQty = (itemId, delta) => {
    setCart((c) =>
      c.map((x) => {
        if (x.itemId !== itemId) return x;
        const next = Math.min(Math.max(x.qty + delta, 1), x.maxQty);
        return { ...x, qty: next };
      })
    );
  };
  const removeFromCart = (itemId) => setCart((c) => c.filter((x) => x.itemId !== itemId));

  const cartTotal = cart.reduce((sum, c) => sum + c.price * c.qty, 0);

  const completeSale = async () => {
    if (cart.length === 0) return;
    const cartSnapshot = cart;
    const payload = saleToRow({
      customer: customer.trim(),
      device: device.trim(),
      items: cartSnapshot.map((c) => ({ itemId: c.itemId, name: c.name, qty: c.qty, price: c.price })),
      total: cartTotal,
      warrantyDays: Number(warrantyDays) || 0,
    });
    try {
      const [row] = await sb("sales", { method: "POST", body: JSON.stringify(payload) });
      setSales((prev) => [...prev, saleFromRow(row)]);

      const updatedItems = [];
      for (const c of cartSnapshot) {
        const item = inventory.find((i) => i.id === c.itemId);
        if (!item) continue;
        const [urow] = await sb(`inventory?id=eq.${c.itemId}`, {
          method: "PATCH",
          body: JSON.stringify({ quantity: item.quantity - c.qty }),
        });
        updatedItems.push(itemFromRow(urow));
      }
      setInventory((prev) => prev.map((i) => updatedItems.find((u) => u.id === i.id) || i));

      setCart([]); setCustomer(""); setDevice(""); setWarrantyDays(0);
      setConfirmMsg(`Venta registrada · ${money(payload.total)}`);
      setReceiptSale(saleFromRow(row));
      setTimeout(() => setConfirmMsg(""), 2500);
    } catch (e) {
      console.error(e);
      alert("No se pudo registrar la venta. Intenta de nuevo.");
    }
  };

  const deleteSale = async (sale) => {
    const ok = window.confirm(`¿Eliminar esta venta de ${money(sale.total)}? Esto devuelve el stock al inventario.`);
    if (!ok) return;
    try {
      const updatedItems = [];
      for (const it of sale.items) {
        const item = inventory.find((i) => i.id === it.itemId);
        if (!item) continue;
        const [urow] = await sb(`inventory?id=eq.${it.itemId}`, {
          method: "PATCH",
          body: JSON.stringify({ quantity: item.quantity + it.qty }),
        });
        updatedItems.push(itemFromRow(urow));
      }
      setInventory((prev) => prev.map((i) => updatedItems.find((u) => u.id === i.id) || i));
      await sb(`sales?id=eq.${sale.id}`, { method: "DELETE" });
      setSales((prev) => prev.filter((s) => s.id !== sale.id));
      triggerUndo(`Venta de ${money(sale.total)} eliminada`, async () => {
        const [row] = await sb("sales", { method: "POST", body: JSON.stringify(saleToRow(sale)) });
        setSales((prev) => [...prev, saleFromRow(row)]);
        const reverted = [];
        for (const it of sale.items) {
          const item = inventory.find((i) => i.id === it.itemId);
          if (!item) continue;
          const [urow] = await sb(`inventory?id=eq.${it.itemId}`, {
            method: "PATCH",
            body: JSON.stringify({ quantity: item.quantity - it.qty }),
          });
          reverted.push(itemFromRow(urow));
        }
        setInventory((prev) => prev.map((i) => reverted.find((u) => u.id === i.id) || i));
      });
    } catch (e) {
      console.error(e);
      alert("No se pudo eliminar la venta.");
    }
  };

  const lowStock = inventory.filter((i) => i.quantity <= i.minStock);
  const inTaller = orders.filter((o) => o.status !== "Entregado");
  const salesToday = sales.filter((s) => s.date.slice(0, 10) === todayStr());
  const salesMonth = sales.filter((s) => s.date.slice(0, 7) === monthStr());
  const totalToday = salesToday.reduce((s, x) => s + x.total, 0);
  const totalMonth = salesMonth.reduce((s, x) => s + x.total, 0);
  const inventoryValue = inventory.reduce((s, i) => s + i.quantity * i.cost, 0);
  const recentSales = [...sales].sort((a, b) => new Date(b.date) - new Date(a.date)).slice(0, 5);

  const NAV = [
    { id: "dashboard", label: "Panel", icon: LayoutDashboard },
    { id: "customers", label: "Clientes", icon: Users },
    { id: "orders", label: "Recepción", icon: ClipboardList },
    { id: "inventory", label: "Inventario", icon: Package },
    { id: "sales", label: "Ventas", icon: ShoppingCart },
    { id: "history", label: "Historial", icon: History },
  ];

  if (loading) {
    return (
      <div className="min-h-screen bg-neutral-950 flex items-center justify-center text-zinc-500 font-mono text-sm">
        Cargando taller…
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-neutral-950 text-zinc-200">
      <style>{`
        @media print {
          body * { visibility: hidden; }
          .print-receipt, .print-receipt * { visibility: visible; }
          .print-receipt { position: fixed; inset: 0; }
        }
      `}</style>
      <header className="border-b border-zinc-800 bg-zinc-950/80 sticky top-0 z-20 backdrop-blur">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="relative w-8 h-8 rounded-md bg-amber-600/15 border border-amber-700/40 flex items-center justify-center">
              <Smartphone size={16} className="text-amber-500" />
              <Wrench size={10} className="text-teal-400 absolute -bottom-1 -right-1" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-mono text-sm tracking-tight text-zinc-100">{BUSINESS_NAME}</span>
                <span
                  title={syncState === "saving" ? "Guardando…" : syncState === "error" ? "Sin conexión" : "Conectado"}
                  className={`w-1.5 h-1.5 rounded-full ${
                    syncState === "saving" ? "bg-amber-400 animate-pulse" :
                    syncState === "error" ? "bg-red-500" : "bg-emerald-500"
                  }`}
                />
              </div>
              <div className="text-[11px] text-zinc-500 -mt-0.5">{BUSINESS_TAGLINE}</div>
            </div>
          </div>
          <nav className="flex items-center gap-1">
            <div className="relative hidden md:block mr-1">
              <Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-zinc-500" />
              <input
                value={globalSearch}
                onChange={(e) => { setGlobalSearch(e.target.value); setGlobalSearchOpen(true); }}
                onFocus={() => setGlobalSearchOpen(true)}
                onBlur={() => setTimeout(() => setGlobalSearchOpen(false), 150)}
                placeholder="Buscar en todo…"
                className="w-40 lg:w-52 bg-zinc-900 border border-zinc-800 rounded-md pl-7 pr-2 py-1.5 text-xs text-zinc-200 focus:outline-none focus:ring-2 focus:ring-amber-600/50"
              />
              {globalSearchOpen && globalSearch.trim() && (
                <div className="absolute right-0 mt-1 w-72 bg-zinc-950 border border-zinc-800 rounded-md shadow-xl z-40 max-h-80 overflow-y-auto text-sm">
                  {globalResults.items.length === 0 && globalResults.orders.length === 0 && globalResults.customers.length === 0 && (
                    <div className="px-3 py-3 text-zinc-500 text-xs">Sin resultados</div>
                  )}
                  {globalResults.customers.length > 0 && (
                    <div>
                      <div className="px-3 pt-2 pb-1 text-[10px] uppercase text-zinc-600">Clientes</div>
                      {globalResults.customers.map((c) => (
                        <button key={c.id} onMouseDown={() => { setTab("customers"); setActiveCustomerId(c.id); setGlobalSearchOpen(false); }}
                          className="w-full text-left px-3 py-1.5 hover:bg-zinc-900 text-zinc-300">{c.name}</button>
                      ))}
                    </div>
                  )}
                  {globalResults.orders.length > 0 && (
                    <div>
                      <div className="px-3 pt-2 pb-1 text-[10px] uppercase text-zinc-600">Recepciones</div>
                      {globalResults.orders.map((o) => (
                        <button key={o.id} onMouseDown={() => { setTab("orders"); setOrderSearch(o.deviceModel); setGlobalSearchOpen(false); }}
                          className="w-full text-left px-3 py-1.5 hover:bg-zinc-900 text-zinc-300">{o.customerName} · {o.deviceModel}</button>
                      ))}
                    </div>
                  )}
                  {globalResults.items.length > 0 && (
                    <div>
                      <div className="px-3 pt-2 pb-1 text-[10px] uppercase text-zinc-600">Inventario</div>
                      {globalResults.items.map((i) => (
                        <button key={i.id} onMouseDown={() => { setTab("inventory"); setInvSearch(i.name); setGlobalSearchOpen(false); }}
                          className="w-full text-left px-3 py-1.5 hover:bg-zinc-900 text-zinc-300">{i.name}</button>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
            {NAV.map((n) => {
              const Icon = n.icon;
              const active = tab === n.id;
              return (
                <button
                  key={n.id}
                  onClick={() => setTab(n.id)}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-sm transition-colors focus:outline-none focus:ring-2 focus:ring-amber-600/60 ${
                    active ? "bg-zinc-800 text-amber-400" : "text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900"
                  }`}
                >
                  <Icon size={15} />
                  <span className="hidden sm:inline">{n.label}</span>
                </button>
              );
            })}
          </nav>
        </div>
      </header>

      {loadError && (
        <div className="max-w-6xl mx-auto px-4 sm:px-6 pt-4">
          <div className="flex items-start gap-2 border border-red-900/50 bg-red-950/20 rounded-lg p-3 text-sm text-red-300">
            <AlertTriangle size={15} className="mt-0.5 shrink-0" />
            <span>{loadError}</span>
          </div>
        </div>
      )}


      <main className="max-w-6xl mx-auto px-4 sm:px-6 py-6">
        {tab === "dashboard" && (
          <div className="space-y-6">
            <div className="grid grid-cols-2 lg:grid-cols-5 gap-3">
              <StatCard label="Ventas de hoy" value={money(totalToday)} sub={`${salesToday.length} venta(s)`} accent="amber" />
              <StatCard label="Ventas del mes" value={money(totalMonth)} sub={`${salesMonth.length} venta(s)`} accent="teal" />
              <StatCard
                label="Equipos en taller"
                value={inTaller.length}
                sub={inTaller.length ? "sin entregar" : "todo entregado"}
                accent={inTaller.length ? "teal" : "emerald"}
              />
              <StatCard
                label="Stock bajo"
                value={lowStock.length}
                sub={lowStock.length ? "revisar inventario" : "todo en orden"}
                accent={lowStock.length ? "red" : "emerald"}
              />
              <StatCard
                label="Recordatorios"
                value={pendingReminders.length}
                sub={pendingReminders.length ? "pendientes hoy" : "al día"}
                accent={pendingReminders.length ? "red" : "emerald"}
              />
            </div>

            {pendingReminders.length > 0 && (
              <div className="border border-amber-900/50 bg-amber-950/10 rounded-lg p-4 space-y-2">
                <div className="flex items-center gap-2 text-amber-400 text-sm font-medium">
                  <Bell size={15} /> Recordatorios de seguimiento
                </div>
                {pendingReminders.map((r) => {
                  const cust = customers.find((c) => c.id === r.customerId);
                  return (
                    <div key={r.id} className="flex items-center justify-between text-sm bg-zinc-900/60 rounded-md px-3 py-2">
                      <div>
                        <span className="text-zinc-200">{cust?.name || "Cliente"}</span>
                        <span className="text-zinc-500"> · {r.message}</span>
                      </div>
                      <button onClick={() => toggleReminderDone(r.id, true)} className="text-xs text-emerald-400 hover:text-emerald-300 flex items-center gap-1">
                        <Check size={13} /> Marcar hecho
                      </button>
                    </div>
                  );
                })}
              </div>
            )}

            {lowStock.length > 0 && (
              <div className="border border-red-900/50 bg-red-950/20 rounded-lg p-4">
                <div className="flex items-center gap-2 text-red-400 text-sm font-medium mb-2">
                  <AlertTriangle size={15} /> Repuestos con stock bajo
                </div>
                <div className="flex flex-wrap gap-2">
                  {lowStock.map((i) => (
                    <span key={i.id} className="text-xs font-mono bg-zinc-900 border border-zinc-800 rounded px-2 py-1 text-zinc-300">
                      {i.name} · {i.quantity} pza
                    </span>
                  ))}
                </div>
              </div>
            )}

            <div>
              <div className="text-sm text-zinc-400 mb-2">Ventas recientes</div>
              {recentSales.length === 0 ? (
                <EmptyState text="Aún no registras ventas. Ve a la pestaña Ventas para hacer la primera." />
              ) : (
                <div className="border border-zinc-800 rounded-lg divide-y divide-zinc-800 overflow-hidden">
                  {recentSales.map((s) => (
                    <div key={s.id} className="flex items-center justify-between px-4 py-2.5 text-sm">
                      <div>
                        <span className="text-zinc-200">{s.customer || "Cliente sin nombre"}</span>
                        <span className="text-zinc-500"> · {s.device || "sin equipo"}</span>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className="text-zinc-500 text-xs font-mono">{new Date(s.date).toLocaleDateString()}</span>
                        <span className="font-mono text-amber-400">{money(s.total)}</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {tab === "customers" && !activeCustomerId && (
          <div className="space-y-4">
            <div className="flex flex-col sm:flex-row gap-3 sm:items-center sm:justify-between">
              <div className="relative w-full sm:w-72">
                <Search size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-zinc-500" />
                <input
                  value={customerSearch}
                  onChange={(e) => setCustomerSearch(e.target.value)}
                  placeholder="Buscar cliente…"
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-md pl-8 pr-3 py-2 text-sm text-zinc-200 focus:outline-none focus:ring-2 focus:ring-amber-600/50"
                />
              </div>
              <button
                onClick={openNewCustomer}
                className="flex items-center justify-center gap-1.5 bg-amber-600 hover:bg-amber-500 text-zinc-950 font-medium text-sm rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-amber-400"
              >
                <Plus size={15} /> Nuevo cliente
              </button>
            </div>
            <button
              onClick={() => downloadCSV("clientes.csv", customers.map((c) => {
                const st = customerStats(c);
                return { nombre: c.name, telefono: c.phone, correo: c.email, equipos: st.visits, total_gastado: st.totalSpent };
              }))}
              className="text-xs text-zinc-500 hover:text-teal-400"
            >
              Exportar clientes a CSV
            </button>

            {filteredCustomers.length === 0 ? (
              <EmptyState text="No hay clientes registrados. Agrégalos aquí o desde Recepción/Ventas para llevar su historial." />
            ) : (
              <div className="grid sm:grid-cols-2 gap-2">
                {filteredCustomers.map((c) => {
                  const stats = customerStats(c);
                  const pending = reminders.filter((r) => r.customerId === c.id && !r.done);
                  return (
                    <button
                      key={c.id}
                      onClick={() => setActiveCustomerId(c.id)}
                      className="text-left border border-zinc-800 bg-zinc-900/40 hover:border-teal-700/60 hover:bg-zinc-900 rounded-md p-4 focus:outline-none focus:ring-2 focus:ring-teal-600/50"
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-zinc-100">{c.name}</span>
                        {pending.length > 0 && <Bell size={13} className="text-amber-400" />}
                      </div>
                      <div className="text-zinc-500 text-xs mt-0.5">{c.phone || "sin teléfono"}</div>
                      <div className="flex items-center justify-between mt-2 text-xs">
                        <span className="text-zinc-500">{stats.visits} equipo(s)</span>
                        <span className="font-mono text-amber-400">{money(stats.totalSpent)}</span>
                      </div>
                    </button>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {tab === "customers" && activeCustomerId && (() => {
          const cust = customers.find((c) => c.id === activeCustomerId);
          if (!cust) { setActiveCustomerId(null); return null; }
          const stats = customerStats(cust);
          const timeline = [
            ...stats.matchSales.map((s) => ({ type: "sale", date: s.date, data: s })),
            ...stats.matchOrders.map((o) => ({ type: "order", date: o.dateReceived, data: o })),
          ].sort((a, b) => new Date(b.date) - new Date(a.date));
          const custReminders = reminders.filter((r) => r.customerId === cust.id).sort((a, b) => new Date(a.dueDate) - new Date(b.dueDate));

          return (
            <div className="space-y-5">
              <button onClick={() => setActiveCustomerId(null)} className="flex items-center gap-1.5 text-sm text-zinc-400 hover:text-zinc-200">
                <ArrowLeft size={15} /> Volver a clientes
              </button>

              <div className="flex flex-wrap items-start justify-between gap-3 border border-zinc-800 rounded-lg p-4 bg-zinc-900/40">
                <div>
                  <div className="text-lg text-zinc-100">{cust.name}</div>
                  <div className="text-sm text-zinc-500">{cust.phone || "sin teléfono"} {cust.email && `· ${cust.email}`}</div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="text-right">
                    <div className="text-xs text-zinc-500">Total gastado</div>
                    <div className="font-mono text-amber-400">{money(stats.totalSpent)}</div>
                  </div>
                  <div className="text-right">
                    <div className="text-xs text-zinc-500">Equipos</div>
                    <div className="font-mono text-zinc-200">{stats.visits}</div>
                  </div>
                  <button onClick={() => openEditCustomer(cust)} className="p-1.5 text-zinc-500 hover:text-amber-400"><Pencil size={15} /></button>
                  <button onClick={() => deleteCustomer(cust.id)} className="p-1.5 text-zinc-500 hover:text-red-400"><Trash2 size={15} /></button>
                </div>
              </div>

              <div className="grid lg:grid-cols-2 gap-5">
                <div className="space-y-2">
                  <div className="text-sm text-zinc-400 flex items-center gap-1.5"><ClipboardList size={14} /> Historial</div>
                  {timeline.length === 0 ? (
                    <EmptyState text="Aún no hay repuestos o ventas asociadas a este nombre." />
                  ) : (
                    <div className="space-y-1.5">
                      {timeline.map((t, idx) => (
                        <div key={idx} className="border border-zinc-800 rounded-md px-3 py-2 text-sm">
                          {t.type === "sale" ? (
                            <div className="flex items-center justify-between">
                              <span className="text-zinc-300">Venta · {t.data.device || "sin equipo"}</span>
                              <span className="font-mono text-amber-400 text-xs">{money(t.data.total)}</span>
                            </div>
                          ) : (
                            <div className="flex items-center justify-between">
                              <span className="text-zinc-300">Recepción · {t.data.deviceBrand} {t.data.deviceModel}</span>
                              <span className={`text-xs rounded-full border px-2 py-0.5 ${STATUS_STYLES[t.data.status]}`}>{t.data.status}</span>
                            </div>
                          )}
                          <div className="text-zinc-600 text-xs mt-0.5">{new Date(t.date).toLocaleDateString()}</div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                <div className="space-y-4">
                  <div>
                    <div className="text-sm text-zinc-400 flex items-center gap-1.5 mb-2"><Bell size={14} /> Recordatorios</div>
                    <div className="space-y-1.5">
                      {custReminders.map((r) => (
                        <div key={r.id} className="flex items-center justify-between border border-zinc-800 rounded-md px-3 py-2 text-sm">
                          <label className="flex items-center gap-2 cursor-pointer">
                            <input type="checkbox" checked={r.done} onChange={(e) => toggleReminderDone(r.id, e.target.checked)}
                              className="accent-amber-600" />
                            <span className={r.done ? "text-zinc-600 line-through" : "text-zinc-300"}>{r.message}</span>
                          </label>
                          <div className="flex items-center gap-2">
                            <span className="text-zinc-600 text-xs font-mono">{r.dueDate}</span>
                            <button onClick={() => deleteReminder(r.id)} className="text-zinc-600 hover:text-red-400"><X size={13} /></button>
                          </div>
                        </div>
                      ))}
                    </div>
                    <div className="flex gap-2 mt-2">
                      <input value={reminderMsg} onChange={(e) => setReminderMsg(e.target.value)} placeholder="Ej. Avisar que está listo"
                        className="flex-1 bg-zinc-900 border border-zinc-800 rounded-md px-2.5 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-amber-600/50" />
                      <input type="date" value={reminderDue} onChange={(e) => setReminderDue(e.target.value)}
                        className="bg-zinc-900 border border-zinc-800 rounded-md px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-amber-600/50" />
                      <button onClick={() => addReminder(cust.id)} className="bg-amber-600 hover:bg-amber-500 text-zinc-950 rounded-md px-3 text-sm">
                        <Plus size={14} />
                      </button>
                    </div>
                  </div>

                  <div>
                    <div className="text-sm text-zinc-400 flex items-center gap-1.5 mb-2"><StickyNote size={14} /> Notas</div>
                    <div className="space-y-1.5">
                      {cust.notes.length === 0 && <div className="text-zinc-600 text-sm">Sin notas todavía.</div>}
                      {[...cust.notes].reverse().map((n, idx) => (
                        <div key={idx} className="border border-zinc-800 rounded-md px-3 py-2 text-sm bg-zinc-900/40">
                          <div className="text-zinc-300">{n.text}</div>
                          <div className="text-zinc-600 text-xs mt-0.5">{new Date(n.date).toLocaleDateString()}</div>
                        </div>
                      ))}
                    </div>
                    <div className="flex gap-2 mt-2">
                      <input value={noteDraft} onChange={(e) => setNoteDraft(e.target.value)} placeholder="Escribe una nota…"
                        className="flex-1 bg-zinc-900 border border-zinc-800 rounded-md px-2.5 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-amber-600/50" />
                      <button onClick={() => addNote(cust.id)} className="bg-amber-600 hover:bg-amber-500 text-zinc-950 rounded-md px-3 text-sm">
                        <Plus size={14} />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          );
        })()}

        {tab === "orders" && (
          <div className="space-y-4">
            <div className="flex flex-col sm:flex-row gap-3 sm:items-center sm:justify-between">
              <div className="relative w-full sm:w-72">
                <Search size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-zinc-500" />
                <input
                  value={orderSearch}
                  onChange={(e) => setOrderSearch(e.target.value)}
                  placeholder="Buscar por cliente o equipo…"
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-md pl-8 pr-3 py-2 text-sm text-zinc-200 focus:outline-none focus:ring-2 focus:ring-amber-600/50"
                />
              </div>
              <button
                onClick={openNewOrder}
                className="flex items-center justify-center gap-1.5 bg-amber-600 hover:bg-amber-500 text-zinc-950 font-medium text-sm rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-amber-400"
              >
                <Plus size={15} /> Recibir equipo
              </button>
            </div>

            {filteredOrders.length === 0 ? (
              <EmptyState text="No hay equipos recibidos. Registra el primero para llevar el control de qué tiene cada técnico." />
            ) : (
              <div className="space-y-2">
                {filteredOrders.map((o) => (
                  <div key={o.id} className="border border-zinc-800 border-t-2 border-t-amber-700/50 rounded-md bg-zinc-900/40 p-4 space-y-2.5">
                    <div className="flex flex-wrap items-start justify-between gap-2">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-zinc-600 text-xs">#{String(o.folio).padStart(4, "0")}</span>
                          <span className="text-zinc-100">{o.customerName || "Cliente sin nombre"}</span>
                          {o.customerPhone && <span className="text-zinc-500 text-xs">· {o.customerPhone}</span>}
                        </div>
                        <div className="text-zinc-400 text-sm">
                          {o.deviceBrand} {o.deviceModel} {o.deviceColor && `· ${o.deviceColor}`}
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-zinc-600 text-xs font-mono">{new Date(o.dateReceived).toLocaleDateString()}</span>
                        <select
                          value={o.status}
                          onChange={(e) => updateOrderStatus(o.id, e.target.value)}
                          className={`text-xs rounded-full border px-2 py-1 focus:outline-none focus:ring-2 focus:ring-amber-600/50 ${STATUS_STYLES[o.status]}`}
                        >
                          {STATUS_OPTIONS.map((s) => <option key={s} value={s}>{s}</option>)}
                        </select>
                      </div>
                    </div>

                    {(o.checklist.length > 0 || o.otherIssue) && (
                      <div className="flex flex-wrap gap-1.5">
                        {o.checklist.map((k) => {
                          const item = CHECKLIST_ITEMS.find((c) => c.key === k);
                          return item ? (
                            <span key={k} className="text-[11px] bg-zinc-800 text-zinc-300 rounded px-1.5 py-0.5">{item.label}</span>
                          ) : null;
                        })}
                        {o.otherIssue && <span className="text-[11px] bg-zinc-800 text-zinc-300 rounded px-1.5 py-0.5">{o.otherIssue}</span>}
                      </div>
                    )}

                    <div className="flex flex-wrap items-center justify-between gap-2 pt-1 border-t border-zinc-800/70">
                      <div className="text-xs text-zinc-500 space-x-3">
                        {o.password && <span>Contraseña: <span className="font-mono text-zinc-300">{o.password}</span></span>}
                        {o.accessories && <span>Deja: {o.accessories}</span>}
                        {o.estimatedCost !== "" && o.estimatedCost != null && <span>Estimado: <span className="font-mono text-amber-400">{money(o.estimatedCost)}</span></span>}
                      </div>
                      <div className="flex gap-1">
                        <button onClick={() => setReceiptOrder(o)} title="Imprimir resguardo" className="p-1.5 text-zinc-500 hover:text-teal-400 focus:outline-none focus:ring-2 focus:ring-teal-600/50 rounded">
                          <ClipboardList size={14} />
                        </button>
                        <button onClick={() => sendOrderToSales(o)} title="Enviar a Ventas" className="p-1.5 text-zinc-500 hover:text-teal-400 focus:outline-none focus:ring-2 focus:ring-teal-600/50 rounded">
                          <ArrowRightCircle size={15} />
                        </button>
                        <button onClick={() => openEditOrder(o)} className="p-1.5 text-zinc-500 hover:text-amber-400 focus:outline-none focus:ring-2 focus:ring-amber-600/50 rounded">
                          <Pencil size={14} />
                        </button>
                        <button onClick={() => deleteOrder(o.id)} className="p-1.5 text-zinc-500 hover:text-red-400 focus:outline-none focus:ring-2 focus:ring-red-600/50 rounded">
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {tab === "inventory" && (
          <div className="space-y-4">
            <div className="flex flex-col sm:flex-row gap-3 sm:items-center sm:justify-between">
              <div className="relative w-full sm:w-72">
                <Search size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-zinc-500" />
                <input
                  value={invSearch}
                  onChange={(e) => setInvSearch(e.target.value)}
                  placeholder="Buscar repuesto…"
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-md pl-8 pr-3 py-2 text-sm text-zinc-200 focus:outline-none focus:ring-2 focus:ring-amber-600/50"
                />
              </div>
              <button
                onClick={openNewItem}
                className="flex items-center justify-center gap-1.5 bg-amber-600 hover:bg-amber-500 text-zinc-950 font-medium text-sm rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-amber-400"
              >
                <Plus size={15} /> Nuevo repuesto
              </button>
            </div>
            <button
              onClick={() => downloadCSV("inventario.csv", inventory.map((i) => ({
                nombre: i.name, marca: i.brand, categoria: i.category, cantidad: i.quantity,
                costo: i.cost, precio: i.price, stock_minimo: i.minStock,
              })))}
              className="text-xs text-zinc-500 hover:text-teal-400"
            >
              Exportar inventario a CSV
            </button>

            {filteredInventory.length === 0 ? (
              <EmptyState text="No hay repuestos todavía. Agrega el primero para empezar a controlar tu inventario." />
            ) : (
              <div className="border border-zinc-800 rounded-lg overflow-hidden overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-zinc-900 text-zinc-500 text-xs uppercase tracking-wide">
                    <tr>
                      <th className="text-left font-normal px-4 py-2.5">Repuesto</th>
                      <th className="text-left font-normal px-4 py-2.5">Categoría</th>
                      <th className="text-right font-normal px-4 py-2.5">Stock</th>
                      <th className="text-right font-normal px-4 py-2.5">Costo</th>
                      <th className="text-right font-normal px-4 py-2.5">Precio</th>
                      <th className="text-right font-normal px-4 py-2.5">Margen</th>
                      <th className="text-right font-normal px-4 py-2.5"></th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-zinc-800">
                    {filteredInventory.map((i) => {
                      const low = i.quantity <= i.minStock;
                      const margin = i.price > 0 ? (((i.price - i.cost) / i.price) * 100).toFixed(0) : "—";
                      return (
                        <tr key={i.id} className="hover:bg-zinc-900/60">
                          <td className="px-4 py-2.5">
                            <div className="text-zinc-100">{i.name}</div>
                            {i.brand && <div className="text-zinc-500 text-xs">{i.brand}</div>}
                          </td>
                          <td className="px-4 py-2.5 text-zinc-400">{i.category}</td>
                          <td className="px-4 py-2.5 text-right font-mono">
                            <span className={low ? "text-red-400" : "text-zinc-200"}>{i.quantity}</span>
                            {low && <AlertTriangle size={12} className="inline ml-1 text-red-400" />}
                          </td>
                          <td className="px-4 py-2.5 text-right font-mono text-zinc-400">{money(i.cost)}</td>
                          <td className="px-4 py-2.5 text-right font-mono text-zinc-200">{money(i.price)}</td>
                          <td className="px-4 py-2.5 text-right font-mono text-teal-400">{margin}{margin !== "—" ? "%" : ""}</td>
                          <td className="px-4 py-2.5 text-right">
                            <div className="flex justify-end gap-1">
                              <button onClick={() => openEditItem(i)} className="p-1.5 text-zinc-500 hover:text-amber-400 focus:outline-none focus:ring-2 focus:ring-amber-600/50 rounded">
                                <Pencil size={14} />
                              </button>
                              <button onClick={() => deleteItem(i.id)} className="p-1.5 text-zinc-500 hover:text-red-400 focus:outline-none focus:ring-2 focus:ring-red-600/50 rounded">
                                <Trash2 size={14} />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}

        {tab === "sales" && (
          <div className="grid lg:grid-cols-5 gap-5">
            <div className="lg:col-span-3 space-y-3">
              <div className="relative">
                <Search size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-zinc-500" />
                <input
                  value={posSearch}
                  onChange={(e) => setPosSearch(e.target.value)}
                  placeholder="Buscar repuesto para vender…"
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-md pl-8 pr-3 py-2 text-sm text-zinc-200 focus:outline-none focus:ring-2 focus:ring-amber-600/50"
                />
              </div>
              {posResults.length === 0 ? (
                <EmptyState text="No hay repuestos disponibles con stock. Agrega inventario primero." />
              ) : (
                <div className="grid sm:grid-cols-2 gap-2">
                  {posResults.map((i) => (
                    <button
                      key={i.id}
                      onClick={() => addToCart(i)}
                      className="text-left border border-zinc-800 bg-zinc-900/60 hover:border-amber-700/60 hover:bg-zinc-900 rounded-md p-3 focus:outline-none focus:ring-2 focus:ring-amber-600/50"
                    >
                      <div className="text-sm text-zinc-100">{i.name}</div>
                      <div className="text-xs text-zinc-500">{i.category} · stock {i.quantity}</div>
                      <div className="font-mono text-amber-400 text-sm mt-1">{money(i.price)}</div>
                    </button>
                  ))}
                </div>
              )}
            </div>

            <div className="lg:col-span-2 border border-zinc-800 rounded-lg p-4 h-fit sticky top-20 space-y-3">
              <div className="text-sm text-zinc-400 font-mono">Venta actual</div>
              <input
                value={customer}
                onChange={(e) => setCustomer(e.target.value)}
                placeholder="Cliente (opcional)"
                className="w-full bg-zinc-900 border border-zinc-800 rounded-md px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-amber-600/50"
              />
              <input
                value={device}
                onChange={(e) => setDevice(e.target.value)}
                placeholder="Equipo / modelo (opcional)"
                className="w-full bg-zinc-900 border border-zinc-800 rounded-md px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-amber-600/50"
              />
              <div className="flex items-center gap-2">
                <span className="text-xs text-zinc-500 whitespace-nowrap">Garantía (días)</span>
                <input
                  type="number" min="0" value={warrantyDays}
                  onChange={(e) => setWarrantyDays(e.target.value)}
                  className="w-20 bg-zinc-900 border border-zinc-800 rounded-md px-2 py-1 text-sm focus:outline-none focus:ring-2 focus:ring-amber-600/50"
                />
              </div>

              {cart.length === 0 ? (
                <div className="text-zinc-600 text-sm py-6 text-center border border-dashed border-zinc-800 rounded-md">
                  Agrega repuestos de la lista
                </div>
              ) : (
                <div className="space-y-2">
                  {cart.map((c) => (
                    <div key={c.itemId} className="flex items-center justify-between text-sm bg-zinc-900/60 rounded-md px-2.5 py-2">
                      <div className="min-w-0">
                        <div className="text-zinc-200 truncate">{c.name}</div>
                        <div className="text-zinc-500 text-xs font-mono">{money(c.price)} c/u</div>
                      </div>
                      <div className="flex items-center gap-2">
                        <button onClick={() => changeCartQty(c.itemId, -1)} className="p-1 text-zinc-500 hover:text-zinc-200"><Minus size={13} /></button>
                        <span className="font-mono w-5 text-center">{c.qty}</span>
                        <button onClick={() => changeCartQty(c.itemId, 1)} className="p-1 text-zinc-500 hover:text-zinc-200"><Plus size={13} /></button>
                        <button onClick={() => removeFromCart(c.itemId)} className="p-1 text-zinc-500 hover:text-red-400 ml-1"><X size={14} /></button>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              <div className="border-t border-zinc-800 pt-3 flex items-center justify-between">
                <span className="text-zinc-400 text-sm">Total</span>
                <span className="font-mono text-lg text-amber-400">{money(cartTotal)}</span>
              </div>
              <button
                onClick={completeSale}
                disabled={cart.length === 0}
                className="w-full flex items-center justify-center gap-1.5 bg-amber-600 hover:bg-amber-500 disabled:bg-zinc-800 disabled:text-zinc-600 text-zinc-950 font-medium text-sm rounded-md py-2 focus:outline-none focus:ring-2 focus:ring-amber-400"
              >
                <Check size={15} /> Registrar venta
              </button>
              {confirmMsg && <div className="text-emerald-400 text-xs text-center font-mono">{confirmMsg}</div>}
            </div>
          </div>
        )}

        {tab === "history" && (
          <div className="space-y-3">
            <div className="flex items-center justify-between text-sm text-zinc-400">
              <span>{sales.length} venta(s) registradas</span>
              <div className="flex items-center gap-3">
                <span className="font-mono text-zinc-300">Total: {money(sales.reduce((s, x) => s + x.total, 0))}</span>
                <button
                  onClick={() => downloadCSV("ventas.csv", sales.map((s) => ({
                    fecha: new Date(s.date).toLocaleString(), cliente: s.customer, equipo: s.device,
                    articulos: s.items.map((it) => `${it.qty}x ${it.name}`).join(" | "), total: s.total,
                    garantia_dias: s.warrantyDays || 0,
                  })))}
                  className="text-xs text-zinc-500 hover:text-teal-400"
                >
                  Exportar a CSV
                </button>
              </div>
            </div>
            {sales.length === 0 ? (
              <EmptyState text="Todavía no hay ventas registradas." />
            ) : (
              <div className="space-y-2">
                {[...sales].sort((a, b) => new Date(b.date) - new Date(a.date)).map((s, idx) => (
                  <details key={s.id} className="border border-zinc-800 border-t-2 border-t-teal-700/50 rounded-md bg-zinc-900/40 open:bg-zinc-900/70">
                    <summary className="cursor-pointer flex items-center justify-between px-4 py-3 text-sm select-none">
                      <div className="flex items-center gap-3">
                        <span className="font-mono text-zinc-600 text-xs">#{String(sales.length - idx).padStart(4, "0")}</span>
                        <span className="text-zinc-200">{s.customer || "Cliente sin nombre"}</span>
                        <span className="text-zinc-500">{s.device && `· ${s.device}`}</span>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className="text-zinc-500 text-xs font-mono">
                          {new Date(s.date).toLocaleDateString()} {new Date(s.date).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                        </span>
                        <span className="font-mono text-amber-400">{money(s.total)}</span>
                      </div>
                    </summary>
                    <div className="px-4 pb-3 pt-1 border-t border-zinc-800/70 space-y-1">
                      {s.items.map((it, i2) => (
                        <div key={i2} className="flex justify-between text-xs font-mono text-zinc-400">
                          <span>{it.qty} × {it.name}</span>
                          <span>{money(it.price * it.qty)}</span>
                        </div>
                      ))}
                      <div className="flex items-center justify-between pt-2">
                        {s.warrantyDays > 0 ? (() => {
                          const until = new Date(s.date); until.setDate(until.getDate() + s.warrantyDays);
                          const vigente = new Date() <= until;
                          return (
                            <span className={`text-[11px] rounded px-1.5 py-0.5 ${vigente ? "bg-emerald-950/40 text-emerald-400" : "bg-zinc-800 text-zinc-500"}`}>
                              Garantía {s.warrantyDays}d · {vigente ? `vigente hasta ${until.toLocaleDateString()}` : "vencida"}
                            </span>
                          );
                        })() : <span />}
                        <div className="flex items-center gap-3">
                          <button onClick={() => setReceiptSale(s)} className="text-xs text-teal-400 hover:text-teal-300">Imprimir recibo</button>
                          <button onClick={() => deleteSale(s)} className="text-xs text-red-400 hover:text-red-300 flex items-center gap-1">
                            <Trash2 size={12} /> Eliminar
                          </button>
                        </div>
                      </div>
                    </div>
                  </details>
                ))}
              </div>
            )}
          </div>
        )}
      </main>

      {modalOpen && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center p-4 z-30">
          <div className="bg-zinc-950 border border-zinc-800 rounded-lg w-full max-w-md p-5 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-zinc-100 font-medium">{editingId ? "Editar repuesto" : "Nuevo repuesto"}</h3>
              <button onClick={() => setModalOpen(false)} className="text-zinc-500 hover:text-zinc-200"><X size={18} /></button>
            </div>
            <Field label="Nombre">
              <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })}
                className="w-full bg-zinc-900 border border-zinc-800 rounded-md px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-amber-600/50" />
            </Field>
            <Field label="Marca / modelo (opcional)">
              <input value={form.brand} onChange={(e) => setForm({ ...form, brand: e.target.value })}
                className="w-full bg-zinc-900 border border-zinc-800 rounded-md px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-amber-600/50" />
            </Field>
            <Field label="Categoría">
              <select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}
                className="w-full bg-zinc-900 border border-zinc-800 rounded-md px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-amber-600/50">
                {CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
              </select>
            </Field>
            <div className="grid grid-cols-2 gap-3">
              <Field label="Cantidad">
                <input type="number" min="0" value={form.quantity} onChange={(e) => setForm({ ...form, quantity: e.target.value })}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-md px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-amber-600/50" />
              </Field>
              <Field label="Stock mínimo">
                <input type="number" min="0" value={form.minStock} onChange={(e) => setForm({ ...form, minStock: e.target.value })}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-md px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-amber-600/50" />
              </Field>
              <Field label="Costo">
                <input type="number" min="0" step="0.01" value={form.cost} onChange={(e) => setForm({ ...form, cost: e.target.value })}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-md px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-amber-600/50" />
              </Field>
              <Field label="Precio de venta">
                <input type="number" min="0" step="0.01" value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-md px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-amber-600/50" />
              </Field>
            </div>
            <div className="flex gap-2 pt-2">
              <button onClick={() => setModalOpen(false)} className="flex-1 border border-zinc-800 text-zinc-300 rounded-md py-2 text-sm hover:bg-zinc-900">Cancelar</button>
              <button onClick={saveItem} className="flex-1 bg-amber-600 hover:bg-amber-500 text-zinc-950 font-medium rounded-md py-2 text-sm">Guardar</button>
            </div>
          </div>
        </div>
      )}

      {orderModalOpen && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center p-4 z-30 overflow-y-auto">
          <div className="bg-zinc-950 border border-zinc-800 rounded-lg w-full max-w-lg p-5 space-y-3 my-6">
            <div className="flex items-center justify-between">
              <h3 className="text-zinc-100 font-medium">{editingOrderId ? "Editar recepción" : "Recibir equipo"}</h3>
              <button onClick={() => setOrderModalOpen(false)} className="text-zinc-500 hover:text-zinc-200"><X size={18} /></button>
            </div>

            <div className="text-xs text-zinc-500 uppercase tracking-wide pt-1">Datos del dueño</div>
            <div className="grid grid-cols-2 gap-3">
              <Field label="Nombre del cliente">
                <input value={orderForm.customerName} onChange={(e) => setOrderForm({ ...orderForm, customerName: e.target.value })}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-md px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-amber-600/50" />
              </Field>
              <Field label="Teléfono">
                <input value={orderForm.customerPhone} onChange={(e) => setOrderForm({ ...orderForm, customerPhone: e.target.value })}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-md px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-amber-600/50" />
              </Field>
            </div>

            <div className="text-xs text-zinc-500 uppercase tracking-wide pt-1">Datos del equipo</div>
            {(() => {
              const w = findActiveWarranty(orderForm.customerName, orderForm.deviceModel);
              if (!w) return null;
              const until = new Date(w.date); until.setDate(until.getDate() + w.warrantyDays);
              return (
                <div className="text-xs bg-emerald-950/30 border border-emerald-800/50 text-emerald-400 rounded-md px-3 py-2">
                  Este cliente/equipo tiene garantía vigente hasta {until.toLocaleDateString()} (venta del {new Date(w.date).toLocaleDateString()}).
                </div>
              );
            })()}
            <div className="grid grid-cols-2 gap-3">
              <Field label="Marca">
                <input value={orderForm.deviceBrand} onChange={(e) => setOrderForm({ ...orderForm, deviceBrand: e.target.value })}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-md px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-amber-600/50" />
              </Field>
              <Field label="Modelo">
                <input value={orderForm.deviceModel} onChange={(e) => setOrderForm({ ...orderForm, deviceModel: e.target.value })}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-md px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-amber-600/50" />
              </Field>
              <Field label="Color">
                <input value={orderForm.deviceColor} onChange={(e) => setOrderForm({ ...orderForm, deviceColor: e.target.value })}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-md px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-amber-600/50" />
              </Field>
              <Field label="Contraseña / patrón">
                <div className="relative">
                  <input
                    type={showPassword ? "text" : "password"}
                    value={orderForm.password}
                    onChange={(e) => setOrderForm({ ...orderForm, password: e.target.value })}
                    className="w-full bg-zinc-900 border border-zinc-800 rounded-md px-3 py-1.5 pr-8 text-sm focus:outline-none focus:ring-2 focus:ring-amber-600/50"
                  />
                  <button type="button" onClick={() => setShowPassword((v) => !v)} className="absolute right-2 top-1/2 -translate-y-1/2 text-zinc-500 hover:text-zinc-300">
                    {showPassword ? <EyeOff size={14} /> : <Eye size={14} />}
                  </button>
                </div>
              </Field>
            </div>

            <div className="text-xs text-zinc-500 uppercase tracking-wide pt-1">Lista de verificación</div>
            <div className="flex flex-wrap gap-1.5">
              {CHECKLIST_ITEMS.map((c) => {
                const selected = orderForm.checklist.includes(c.key);
                return (
                  <button
                    key={c.key}
                    type="button"
                    onClick={() => toggleChecklistItem(c.key)}
                    className={`text-xs rounded-full px-2.5 py-1 border focus:outline-none focus:ring-2 focus:ring-amber-600/50 ${
                      selected ? "bg-amber-600 border-amber-500 text-zinc-950" : "bg-zinc-900 border-zinc-800 text-zinc-400 hover:border-zinc-700"
                    }`}
                  >
                    {c.label}
                  </button>
                );
              })}
            </div>
            <Field label="Otra descripción (opcional)">
              <textarea rows={2} value={orderForm.otherIssue} onChange={(e) => setOrderForm({ ...orderForm, otherIssue: e.target.value })}
                className="w-full bg-zinc-900 border border-zinc-800 rounded-md px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-amber-600/50" />
            </Field>

            <div className="grid grid-cols-2 gap-3">
              <Field label="Accesorios que deja">
                <input value={orderForm.accessories} onChange={(e) => setOrderForm({ ...orderForm, accessories: e.target.value })}
                  placeholder="Cargador, funda…"
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-md px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-amber-600/50" />
              </Field>
              <Field label="Costo estimado">
                <input type="number" min="0" step="0.01" value={orderForm.estimatedCost} onChange={(e) => setOrderForm({ ...orderForm, estimatedCost: e.target.value })}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-md px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-amber-600/50" />
              </Field>
            </div>
            <Field label="Estado">
              <select value={orderForm.status} onChange={(e) => setOrderForm({ ...orderForm, status: e.target.value })}
                className="w-full bg-zinc-900 border border-zinc-800 rounded-md px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-amber-600/50">
                {STATUS_OPTIONS.map((s) => <option key={s} value={s}>{s}</option>)}
              </select>
            </Field>

            <div className="flex gap-2 pt-2">
              <button onClick={() => setOrderModalOpen(false)} className="flex-1 border border-zinc-800 text-zinc-300 rounded-md py-2 text-sm hover:bg-zinc-900">Cancelar</button>
              <button onClick={saveOrder} className="flex-1 bg-amber-600 hover:bg-amber-500 text-zinc-950 font-medium rounded-md py-2 text-sm">Guardar</button>
            </div>
          </div>
        </div>
      )}

      {customerModalOpen && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center p-4 z-30">
          <div className="bg-zinc-950 border border-zinc-800 rounded-lg w-full max-w-md p-5 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-zinc-100 font-medium">{editingCustomerId ? "Editar cliente" : "Nuevo cliente"}</h3>
              <button onClick={() => setCustomerModalOpen(false)} className="text-zinc-500 hover:text-zinc-200"><X size={18} /></button>
            </div>
            <Field label="Nombre">
              <input value={customerForm.name} onChange={(e) => setCustomerForm({ ...customerForm, name: e.target.value })}
                className="w-full bg-zinc-900 border border-zinc-800 rounded-md px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-amber-600/50" />
            </Field>
            <Field label="Teléfono">
              <input value={customerForm.phone} onChange={(e) => setCustomerForm({ ...customerForm, phone: e.target.value })}
                className="w-full bg-zinc-900 border border-zinc-800 rounded-md px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-amber-600/50" />
            </Field>
            <Field label="Correo (opcional)">
              <input value={customerForm.email} onChange={(e) => setCustomerForm({ ...customerForm, email: e.target.value })}
                className="w-full bg-zinc-900 border border-zinc-800 rounded-md px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-amber-600/50" />
            </Field>
            <div className="flex gap-2 pt-2">
              <button onClick={() => setCustomerModalOpen(false)} className="flex-1 border border-zinc-800 text-zinc-300 rounded-md py-2 text-sm hover:bg-zinc-900">Cancelar</button>
              <button onClick={saveCustomer} className="flex-1 bg-amber-600 hover:bg-amber-500 text-zinc-950 font-medium rounded-md py-2 text-sm">Guardar</button>
            </div>
          </div>
        </div>
      )}

      {receiptSale && (
        <div className="print-receipt fixed inset-0 bg-black/60 flex items-center justify-center p-4 z-40 print:static print:bg-white print:p-0">
          <div className="bg-white text-zinc-900 rounded-lg w-full max-w-sm p-6 space-y-3 font-mono text-sm print:shadow-none print:max-w-full">
            <div className="flex items-center justify-between print:hidden">
              <h3 className="font-sans font-medium">Recibo</h3>
              <button onClick={() => setReceiptSale(null)} className="text-zinc-500 hover:text-zinc-900"><X size={18} /></button>
            </div>
            <div className="text-center border-b-2 border-zinc-900 pb-3">
              <div className="font-sans font-bold text-lg tracking-tight">{BUSINESS_NAME.toUpperCase()}</div>
              <div className="text-[11px] text-zinc-500 font-sans">{BUSINESS_TAGLINE}</div>
              <div className="text-[11px] text-zinc-400 font-sans mt-1">Recibo de venta</div>
            </div>
            <div>Fecha: {new Date(receiptSale.date).toLocaleString()}</div>
            {receiptSale.customer && <div>Cliente: {receiptSale.customer}</div>}
            {receiptSale.device && <div>Equipo: {receiptSale.device}</div>}
            <div className="border-t border-dashed border-zinc-400 pt-2 space-y-1">
              {receiptSale.items.map((it, i) => (
                <div key={i} className="flex justify-between"><span>{it.qty}x {it.name}</span><span>{money(it.price * it.qty)}</span></div>
              ))}
            </div>
            <div className="border-t border-dashed border-zinc-400 pt-2 flex justify-between font-semibold">
              <span>Total</span><span>{money(receiptSale.total)}</span>
            </div>
            {receiptSale.warrantyDays > 0 && (
              <div className="border-t border-dashed border-zinc-400 pt-2 font-sans text-[11px] leading-snug text-zinc-600">
                <div className="font-semibold text-zinc-800 mb-0.5">Garantía: {receiptSale.warrantyDays} día(s)</div>
                Cubre únicamente la falla reparada, contada a partir de la fecha de esta venta.
                No cubre daños por golpes, caídas, humedad/líquidos, ni intervención de terceros.
                Indispensable presentar este recibo para hacerla válida.
              </div>
            )}
            <div className="text-center text-[10px] text-zinc-400 font-sans pt-1">¡Gracias por su preferencia!</div>
            <button onClick={() => window.print()} className="print:hidden w-full bg-zinc-900 text-white rounded-md py-2 text-sm font-sans mt-2">Imprimir</button>
          </div>
        </div>
      )}

      {receiptOrder && (
        <div className="print-receipt fixed inset-0 bg-black/60 flex items-center justify-center p-4 z-40 print:static print:bg-white print:p-0">
          <div className="bg-white text-zinc-900 rounded-lg w-full max-w-sm p-6 space-y-2 font-mono text-sm print:shadow-none print:max-w-full">
            <div className="flex items-center justify-between print:hidden">
              <h3 className="font-sans font-medium">Resguardo</h3>
              <button onClick={() => setReceiptOrder(null)} className="text-zinc-500 hover:text-zinc-900"><X size={18} /></button>
            </div>
            <div className="text-center border-b-2 border-zinc-900 pb-3">
              <div className="font-sans font-bold text-lg tracking-tight">{BUSINESS_NAME.toUpperCase()}</div>
              <div className="text-[11px] text-zinc-500 font-sans">{BUSINESS_TAGLINE}</div>
              <div className="text-[11px] text-zinc-400 font-sans mt-1">Resguardo de recepción #{String(receiptOrder.folio).padStart(4, "0")}</div>
            </div>
            <div>Fecha: {new Date(receiptOrder.dateReceived).toLocaleString()}</div>
            <div>Cliente: {receiptOrder.customerName} {receiptOrder.customerPhone && `· ${receiptOrder.customerPhone}`}</div>
            <div>Equipo: {receiptOrder.deviceBrand} {receiptOrder.deviceModel} {receiptOrder.deviceColor}</div>
            {receiptOrder.accessories && <div>Accesorios: {receiptOrder.accessories}</div>}
            {(receiptOrder.checklist.length > 0 || receiptOrder.otherIssue) && (
              <div className="border-t border-dashed border-zinc-400 pt-2">
                <div className="font-sans text-xs text-zinc-500 mb-1">Problema reportado:</div>
                <div>{receiptOrder.checklist.map((k) => CHECKLIST_ITEMS.find((c) => c.key === k)?.label).filter(Boolean).join(", ")}{receiptOrder.otherIssue ? ` ${receiptOrder.otherIssue}` : ""}</div>
              </div>
            )}
            {receiptOrder.estimatedCost != null && receiptOrder.estimatedCost !== "" && (
              <div className="border-t border-dashed border-zinc-400 pt-2">Costo estimado: {money(receiptOrder.estimatedCost)}</div>
            )}
            <div className="border-t border-dashed border-zinc-400 pt-2 font-sans text-[11px] leading-snug text-zinc-600">
              El equipo se entrega únicamente contra este resguardo. {BUSINESS_NAME} no se hace responsable por equipos no reclamados después de 30 días naturales a partir de la fecha de recepción.
            </div>
            <button onClick={() => window.print()} className="print:hidden w-full bg-zinc-900 text-white rounded-md py-2 text-sm font-sans mt-2">Imprimir</button>
          </div>
        </div>
      )}

      {tab !== "sales" && (
        <button
          onClick={() => setTab("sales")}
          title="Venta rápida"
          className="fixed bottom-5 right-5 z-30 print:hidden flex items-center gap-2 bg-amber-600 hover:bg-amber-500 text-zinc-950 rounded-full pl-4 pr-5 py-3 shadow-lg shadow-black/40 font-medium text-sm focus:outline-none focus:ring-2 focus:ring-amber-400"
        >
          <ShoppingCart size={17} /> Venta rápida
        </button>
      )}

      {undoToast && (
        <div className="fixed bottom-5 left-1/2 -translate-x-1/2 z-40 print:hidden flex items-center gap-3 bg-zinc-900 border border-zinc-700 rounded-full pl-4 pr-2 py-2 shadow-xl text-sm">
          <span className="text-zinc-300">{undoToast.message}</span>
          <button
            onClick={async () => { const fn = undoToast.restoreFn; setUndoToast(null); await fn(); }}
            className="text-amber-400 font-medium hover:text-amber-300 px-2 py-1 rounded"
          >
            Deshacer
          </button>
          <button onClick={() => setUndoToast(null)} className="text-zinc-600 hover:text-zinc-400 p-1"><X size={14} /></button>
        </div>
      )}
    </div>
  );
}

function StatCard({ label, value, sub, accent }) {
  const colors = {
    amber: "text-amber-400 border-t-amber-700/60",
    teal: "text-teal-400 border-t-teal-700/60",
    zinc: "text-zinc-200 border-t-zinc-700",
    red: "text-red-400 border-t-red-700/60",
    emerald: "text-emerald-400 border-t-emerald-700/60",
  };
  return (
    <div className={`border border-zinc-800 border-t-2 ${colors[accent]} bg-zinc-900/40 rounded-lg p-3.5`}>
      <div className="text-[11px] text-zinc-500 uppercase tracking-wide">{label}</div>
      <div className="font-mono text-xl mt-1">{value}</div>
      <div className="text-xs text-zinc-500 mt-0.5">{sub}</div>
    </div>
  );
}

function Field({ label, children }) {
  return (
    <label className="block space-y-1">
      <span className="text-xs text-zinc-500">{label}</span>
      {children}
    </label>
  );
}

function EmptyState({ text }) {
  return (
    <div className="border border-dashed border-zinc-800 rounded-lg py-10 text-center text-zinc-500 text-sm">
      {text}
    </div>
  );
}
